import os
import shutil

# GLOBAL VARIABLES

action_choice = "null"
fichier = "null"
directory = "null"
stop = False
desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
current_directory = desktop_path
content = ["null"]
ls_for = 0
source = "null"
destination = "null"
old_name = ""
new_name = ""
selected_file = "null"
saved_dir = "null"


def error1():  # PermissionError
    print("erreur \ncode d'erreur 1")

# fix desktop synced with OneDrive

home = os.path.expanduser("~")

desktop_path_1 = os.path.join(home, "Desktop")
desktop_path_2 = os.path.join(home, "OneDrive", "Desktop")

if os.path.isdir(desktop_path_1):
    desktop_path = desktop_path_1
elif os.path.isdir(desktop_path_2):
    desktop_path = desktop_path_2
else:
    print("Error : unable to find desktop.")

# =========================================================================================================================
#                                       OFFICIAL MODULES
# =========================================================================================================================

def help():
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        help_path = os.path.join(script_dir, "HELP_TEXT.txt")
        with open(help_path, "r") as f:
            print(f.read())
    except Exception:
        print("Unable to read HELP_TEXT.txt")

def back():
    try:
        os.chdir("..")
        print("moved back to :", os.getcwd())
    except Exception as e:
        print("unable to go back :", e)

def cdir():
    directory = input("Path (blank = desktop) : ")
    if directory.strip() == "":
        directory = desktop_path
    try :
        os.chdir(directory)
        print("Choosed path : ", directory)
    except PermissionError :
        error1()
    except Exception as e :
        print("error : ", e)


def goto():
    directory = input("Go to path: ")
    if directory.strip() == "":
        directory = desktop_path
    try:
        os.chdir(directory)
        print("Moved to :", os.getcwd())
    except FileNotFoundError:
        print("the specified path does not exist.")
    except PermissionError:
        error1()
    except Exception as e:
        print("error : ", e)


def wdir():
    fichier = input("Folder name : ")
    try:
        os.mkdir(fichier)
        print("Folder created here : ", os.getcwd())
    except PermissionError:
        error1()
    except Exception as e:
        print("an error occured : ", e)

def rdir():
    fichier = input("What folder do you wish to delete? : ")
    try:
        shutil.rmtree(fichier)
        print("folder deleted : ", fichier)
    except FileNotFoundError:
        print("the specified folder does not exist.")
    except PermissionError:
        error1()
    except Exception as e:
        print("an error occured : ", e)

def rfile():
    fichier = input("What file do you wish to delete? : ")
    try:
        os.remove(fichier)
        print("file deleted : ", fichier)
    except FileNotFoundError:
        print("the specified file does not exist.")
    except PermissionError:
        error1()
    except Exception as e:
        print("an error occured : ", e)

def wfile():
    fichier = input("File name : ")
    try:
        with open(fichier, "w") as file:
            file.write(fichier)
        print("file created here : ", os.getcwd())
    except PermissionError:
        error1()
    except Exception as e:
        print("an error occured : ", e)

def rn():
    try:
        old_name = input("File/Folder to rename : ")
        new_name = input("New name : ")
        os.rename(old_name, new_name)
        print("renamed with success.")
    except FileNotFoundError:
        print("Specified File/Folder does not exist.")
    except PermissionError:
        print(error1())
    except FileExistsError:
        print("This name is already used here.")
    except Exception as e:
        print("an error occured : ", e)

def ls():
    current_directory = os.getcwd()
    print("Current directory : ", current_directory)
    content = os.listdir(".")
    print("This folder contains : ")
    ls_for = 0
    for element in content:
        ls_for = ls_for + 1
        print(ls_for, ":", element)

def mv():
    try:
        source = input("File/Folder to move : ")
        destination = input("destination : ")
        shutil.move(source, destination)
        print("File/Folder moved successfully.")
    except FileNotFoundError:
        print("the specified File/Folder does not exist.")
    except PermissionError:
        error1()
    except Exception as e:
        print("an error occured : ", e)

def dog():
    try:
        selected_file = input("What do you wish to run? : ")
        os.startfile(selected_file)
    except FileNotFoundError:
        print("the specified File/Folder does not exist.")
    except PermissionError:
        error1()
    except IsADirectoryError:
        print("unable to run this folder")
    except Exception as e:
        print("an error occured : ", e)




# ===============================================================================
#                         NON-OFFICIAL MODULES
# ===============================================================================