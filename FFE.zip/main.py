from modules import cdir, back, wdir, rdir, rfile, wfile, rn, ls, mv, dog, goto, help
import os

# ==================================
#            VARIABLES
# ==================================
action_choice = "null"
fichier = "null"
stop = False
desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
directory = desktop_path
current_directory = desktop_path
content = ["null"]
ls_for = 0
source = "null"
destination = "null"
old_name = ""
new_name = ""
selected_file = "null"
saved_dir = "null"

#                                                            message de bienvenue

print("\033[34m===============================================\n       FLOOF FILES EXPLORER 1.0\n===============================================\033[0m")

#                                                                  action_choice


while not stop :


    action_choice = input("[FFE] >  ")

   
    if action_choice == "cdir":
        cdir()

    elif action_choice == "back":
        back()

    elif action_choice == "wdir":
        wdir()

    elif action_choice == "rdir":
        rdir()

    elif action_choice == "rfile":
        rfile()

    elif action_choice == "wfile":
        wfile()

    elif action_choice == "rn":
        rn()

    elif action_choice == "ls":
        ls()

    elif action_choice == "mv":
        mv()

    elif action_choice == "dog":
        dog()
    
    elif action_choice == "goto":
        goto()

    elif action_choice == "help":
        help()

    elif action_choice == "exit":
        print("Floof Files Explorer 1.0")
        stop = True


    else :
        print("Error \Error code 0")
